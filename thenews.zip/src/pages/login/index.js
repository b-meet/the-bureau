import Login from "@/components/global/authentication/Login";

const LoginPage = () => {
	return (
		<>
			<Login />
		</>
	);
};

export default LoginPage;
