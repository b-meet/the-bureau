const routes = {
	INVESTIGATION: "/investigations",
	GEOPOLITICS_FINANCE: "/geopolitics-finance",
	HEALTH: "/health",
	TECHNOLOGY: "/technology",
	NATIONAL_SECURITY: "/national-security",
	OP_ANALYSIS: "/op-analysis",
	ABOUT: "/about",
	ARTICLE: "/article/",
	LOGIN: "/login",
};

export default routes;
